In this folder you can write your custom function which you are going to needed in this project and export it .

Eg : You can make Discount.js which will calculate discount in cart by taking arguments like (originalPrice,discountPrice) and it will return you discount in number which you can show in cart.