### Class Notes

1. Setup Redux Architecture
   - Redux folder
     - action.js
     - actionTypes.js
     - reducer.js
     - store.js
     
2. Setup json-server
   "server": "json-server --watch db.json --port 8080",

3. Creating folders for Pages and Components
   Pages - Homepage
   Components - Todos (we need fetch the data present in the db.json file, using json-server) - TodoInput (POST)
