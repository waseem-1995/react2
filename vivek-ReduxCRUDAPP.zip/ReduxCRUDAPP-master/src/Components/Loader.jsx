import { Center } from "@chakra-ui/react";
import React from "react";
import "../App.css";

const Loader = () => {
  return <Center className="bars-7"></Center>;
};

export default Loader;
