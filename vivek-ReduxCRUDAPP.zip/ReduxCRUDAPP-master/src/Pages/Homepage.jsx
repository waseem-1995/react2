import React from "react";
import Todos from "../Components/Todos";

const Homepage = () => {
  return (
    <div>
     <Todos /> 
        
    </div>
  );
};

export default Homepage;
