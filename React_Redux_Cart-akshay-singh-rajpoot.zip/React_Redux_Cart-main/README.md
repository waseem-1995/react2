# React-Redux
Practice
![image](https://user-images.githubusercontent.com/97354310/181919684-c7756e66-5589-40fe-8024-7b2cf717032d.png)
