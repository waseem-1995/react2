import { Text } from '@chakra-ui/react';
import React from 'react'

const About = () => {
  return (
    <div>
      <Text fontSize={ '6xl' }>About </Text>
    </div>
  )
}

export default About