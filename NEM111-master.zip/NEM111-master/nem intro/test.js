const sum=(a,b)=>{
    console.log(a+b)
}

module.exports=sum

const mul=(a,b)=>{
    console.log(a*b)
}
module.exports=mul


// module.exports={sum,mul}
