const sum=(a,b)=>{
    return Number(a)+Number(b)
}
// module.exports(sum)
const sub=(a,b)=>{
    return Number(a)-Number(b)
}
const mul=(a,b)=>{
    return Number(a)*Number(b)
}
const div=(a,b)=>{
    return Number(a)/Number(b)
}

module.exports={sum,sub,mul,div}