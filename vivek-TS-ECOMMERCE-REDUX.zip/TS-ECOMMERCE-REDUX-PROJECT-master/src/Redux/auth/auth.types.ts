export const USER_LOGIN_REQUEST = "userLogin/request";
export const USER_LOGIN_ERROR = "userLogin/error";
export const USER_LOGIN_SUCCESS = "userLogin/success";
