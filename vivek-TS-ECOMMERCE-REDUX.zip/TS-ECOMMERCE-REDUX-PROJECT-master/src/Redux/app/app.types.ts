export const PRODUCT_REQUEST = "products/request";
export const PRODUCT_ERROR = "products/error";
export const GET_PRODUCTS_SUCCESS = "getProducts/success";
export const UPDATE_PRODUCT_SUCCESS = "updateProduct/success";
