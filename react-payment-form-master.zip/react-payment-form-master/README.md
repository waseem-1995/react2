# React Payment Form UI
- Made this for a task given to me..
- To Run
  - Clone Repo
  - Inside code directory
     - > npm install
     - > npm start
 ## Demo
 
 ![](./demo.gif)
 
 ## Author 
  [Nikhil Sahu](http://nikhilsahu.me/)
