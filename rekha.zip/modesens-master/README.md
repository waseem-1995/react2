# Coolmart
### An online eCommerce website Buy Streetwear Collection for Men & Women Online | Click&Buy.
### A collaborative project built by a team of 4 Member executed in 4 days
### 🔗 Checkout [Deployed Link](https://cooolmart.vercel.app/) 
# Features

### Login, Signup & Logout, and otp functionality
### Sorting and Filtering function based on product type, price, categories, etc.
### Add to cart functionality, Payment page
### Categories for different types of products
### Products add functionality 

# Tech Stack 
### HTML | CSS | JavaScript  |React | Redux | Redux-thunk | Chakra UI
### Home page
![](https://github.com/Surendrakumar878/hissing-love-5128/blob/master/public/Screenshot%20(122).png?raw=true)

### Login & Sign up Page
![](https://github.com/Surendrakumar878/hissing-love-5128/blob/master/public/Screenshot%20(120).png?raw=true)
### Sign Up Page
![](https://github.com/Surendrakumar878/hissing-love-5128/blob/master/public/Screenshot%20(121).png?raw=true)

### Cart Page
![](https://github.com/Surendrakumar878/hissing-love-5128/blob/master/public/Screenshot%20(123).png?raw=true)

### Search bar Page
![](https://github.com/Surendrakumar878/hissing-love-5128/blob/master/public/Screenshot%20(124).png?raw=true)
### mens Page
![](https://github.com/Surendrakumar878/hissing-love-5128/blob/master/public/Screenshot%20(125).png?raw=true)





