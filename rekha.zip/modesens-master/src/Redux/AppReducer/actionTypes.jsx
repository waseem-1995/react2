export const GET_DATA_REQUEST = "GET_DATA_REQUEST"
export const GET_DATA_SUCCESS = "GET_DATA_SUCCESS"
export const GET_DATA_FAILURE = "GET_DATA_FAILURE"


// -------------------------------for product description page dont change------------------------------------
export const GET_PRODUCT_DETAILS_REQ="GET_PRODUCT_DETAILS_REQ";
export const GET_PRODUCT_DETAILS_SUCCESS= "GET_PRODUCT_DETAILS_SUCCESS";
export const GET_PRODUCT_DETAILS_ERROR="GET_PRODUCT_DETAILS_ERROR"
// -------------------------------for product description page dont change------------------------------------