import React from 'react'
import WhyMod from '../components/WhyModesens/WhyMod'

const WhyModesensPage = () => {
  return (
    <div style={{textAlign:"center"}}>
      <WhyMod/>
    </div>
  )
}

export default WhyModesensPage
