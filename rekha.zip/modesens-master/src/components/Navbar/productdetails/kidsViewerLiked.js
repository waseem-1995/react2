const kidsViewersLiked=[
    {
    "id": 60,
    "available": true,
    "image": "https://cdn.modesens.com/product/24969331_41?w=400&",
    "title": "BURBERRY",
    "description": "Kids Babys & and Little boys Logo",
    "price": 170,
    "stores": 11,
    "category": "kids",
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    },
    {
    "id": 61,
    "available": true,
    "image": "https://cdn.modesens.com/product/21867878_29?w=400&",
    "title": "BURBERRY",
    "description": "Kids Beige vintage Check Head band",
    "price": 160,
    "stores": 12,
    "category": "kids",
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    },
    {
    "id": 62,
    "available": true,
    "image": "https://res.cloudinary.com/ssenseweb/image/upload/b_white%2Cc_lpad%2Cg_center%2Ch_960%2Cw_960/c_scale%2Ch_680/f_auto%2Cdpr_1.0/221376M718000_1.jpg",
    "title": "BURBERRY",
    "description": "Burberry kids graham checked panelled",
    "price": 220,
    "stores": 14,
    "category": "kids",
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    },
    {
    "id": 63,
    "available": true,
    "image": "https://cdn.modesens.com/product/37634880_2?w=400&",
    "title": "BURBERRY",
    "description": "t Shirt",
    "price": 133,
    "stores": 12,
    "category": "kids",
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    },
    {
    "id": 64,
    "available": true,
    "image": "https://cdn.modesens.com/availability/30845999?w=400&",
    "title": "BURBERRY",
    "description": "Burberry kids graham checked & Icon Stripe",
    "price": 100,
    "stores": 14,
    "category": "kids",
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    },
    {
    "id": 65,
    "available": true,
    "image": "https://images.bloomingdalesassets.com/is/image/BLM/products/9/optimized/11080829_fpx.tif?op_sharpen=1&wid=700",
    "title": "BURBERRY",
    "description": "Kids Boys Abtot Logo Print t shirt ",
    "price": 110,
    "stores": 10,
    "category": "kids",
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    },
    {
    "id": 66,
    "available": true,
    "image": "https://cdn.modesens.com/availability/42137543?w=400&",
    "title": "BURBERRY",
    "description": "Unisex Mini Lakhall Icon Stripped Logo",
    "price": 126,
    "stores": 11,
    "category": "kids",
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    },
    {
    "id": 67,
    "available": true,
    "image": "https://res.cloudinary.com/ssenseweb/image/upload/b_white%2Cc_lpad%2Cg_center%2Ch_960%2Cw_960/c_scale%2Ch_680/f_auto%2Cdpr_1.0/212376M708001_1.jpg",
    "title": "BURBERRY",
    "description": "Girls Rosie check Leather Chlsea Boots",
    "price": 470,
    "stores": 10,
    "category": "kids",
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    }]

    export {kidsViewersLiked};
    