const beautyViewersLiked=[
    {
    "id": 31,
    "available": true,
    "image": "https://cdn.modesens.com/product/6678065_76?w=400&",
    "title": "SISLEY PARIS ",
    "description": "Black rose precious Face oil 25ml/0.84oz",
    "price": 200,
    "stores": 9,
    "category": "beauty",
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    },
    {
    "id": 32,
    "available": true,
    "image": "https://n.nordstrommedia.com/id/sr3/d2996d5b-6196-42db-b401-c7032c0b90a8.jpeg?w=780&h=838",
    "title": "SISLEY PARIS ",
    "description": "soapless Gentle Foaming Cleaning, 85G",
    "price": 100,
    "stores": 9,
    "category": "beauty",
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    },
    {
    "id": 33,
    "available": true,
    "image": "https://n.nordstrommedia.com/id/sr3/d4522742-c93b-483e-b2af-ff01f1704573.jpeg?w=780&h=838",
    "title": "SISLEY PARIS ",
    "description": "Sisley-pairs velvet Nourishing Cream ",
    "price": 110,
    "stores": 9,
    "category": "beauty",
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    },
    {
    "id": 34,
    "available": true,
    "image": "https://n.nordstrommedia.com/id/sr3/464f00db-8256-4d70-895b-1b8f0e9a65f4.jpeg?w=780&h=838",
    "title": "SISLEY PARIS ",
    "description": "Sisley blush Brush, Women's in White",
    "price": 170,
    "stores": 9,
    "category": "beauty",
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    },
    {
    "id": 35,
    "available": true,
    "image": "https://cdn.modesens.com/product/20609416_27?w=400&",
    "title": "CHARLOTTE TILBURY",
    "description": "The Air-brush kabuki Bronzing Brush In",
    "price": 35,
    "category": "beauty",
    "stores": 10,
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    },
    {
    "id": 36,
    "available": true,
    "image": "https://cdn.modesens.com/product/20950740_22?w=400&",
    "title": "SISLEY PARIS",
    "description": "Sisly- paris Triple oil Balm Make-up",
    "price": 99,
    "stores": 9,
    "category": "beauty",
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    },
    {
    "id": 37,
    "available": true,
    "image": "https://cdn.modesens.com/product/6678166_58?w=400&",
    "title": "SISLEY PARIS",
    "description": "5.O Oz Sisleya Essential Skin Care Lotion In",
    "price": 180,
    "stores": 9,
    "category": "beauty",
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    },
    {
    "id": 38,
    "available": true,
    "image": "https://cdn.modesens.com/product/6291076_15?w=400&",
    "title": "SISLEY PARIS",
    "description": "Instant eclat Instant Glow Primer 30ml In",
    "price": 78,
    "category": "beauty",
    "stores": 10,
    "rating": {
    "rate": 1.9,
    "count": 100
    }
    }]

    export {beautyViewersLiked};
    