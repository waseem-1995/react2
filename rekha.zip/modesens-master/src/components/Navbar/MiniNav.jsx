import React from 'react'

const MiniNav = ({ty}) => {
  console.log("helo")
  return (
    <div>
      hello
    </div>
  )
}

export default MiniNav