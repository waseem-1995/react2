import React from 'react'

const CommuSlide = () => {
  return (
    <div>
        
        
        <img src="./Images/comm1.png" alt="a" />
    </div>
  )
}

export default CommuSlide